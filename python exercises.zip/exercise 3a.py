#program 1
x =5
while x<=100:
    print(x, "$ =",x*3.75, "saudi riyal ,",x, "$ = ", x*3.64, " qatari riyal,",x,"$ = ", x*31.45, " Thai baht,",x," $ = ", x*0.96, " swiss frank,",x, "$= ",x*1.39, " singapore dollar \n" )
    x+=5

# program 2
z=1
x = eval(input("how many items have you bought?"))
y = eval(input("what is the price"))
total =0
while z !=0:

    if x>=10:
        total += x*y*1.12 - (x*y*0.03)
    else:
        total += x*y*1.12

    z = eval(input("do you have more items? (1 for yes and 0 for no) "))
    if z==1:
        x = eval(input("how many items have you bought?"))
        y = eval(input("what is the price"))
    else:
        break


print("your total is(including 12% tax): ", total, "\n thank you and have a good day")