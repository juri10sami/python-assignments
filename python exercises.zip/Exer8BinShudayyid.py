class Person:
    def __init__(self, name, age, ID):
        self.name = name
        self.age = age
        self.ID = ID

    def __str__(self):
        return "name: " + str(self.name) + " age: " + str(self.age) + " ID " + str(self.ID)


class Student(Person):
    def __init__(self, name, age, ID, major, creditHours):
        super().__init__(name, age, ID)
        self.major = major
        self.creditHours = creditHours

    def __str__(self):
        return "name: " + str(self.name) + " age: " + str(self.age) + " ID " + str(
            self.ID) + " major: " + str(self.major) + " creditHours: " + str(self.creditHours)

    def getcreditHours(self):
        return self.creditHours

    def setcreditHours(self, creditHours):
        self.creditHours = creditHours

    def calculateTuitionFee(self):
        return 500 * self.creditHours - self.identifyDiscount()

    def identifyDiscount(self):
        if self.creditHours > 10:
            return 0.05 * (500 * self.creditHours)
        else:
            return 0


per1 = Person("nora", 18, 1111)
print(per1.__str__())

st1 = Student("sarah", 17, 2222, "chemistry", 10)
print(st1.__str__())
print("discount: " + str(st1.identifyDiscount()))
print("total tuition fee: " + str(st1.calculateTuitionFee()))

st2 = Student("zainab", 18, 3333, "physics", 15)
print(st2.__str__())
print("discount: " + str(st2.identifyDiscount()))
print("total tuition fee: " + str(st2.calculateTuitionFee()))

st3 = Student("lira", 18, 4444, "computer science", 15)
print(st3.__str__())
st3.setcreditHours(9)
print("discount: " + str(st3.identifyDiscount()))
print("total tuition fee: " + str(st3.calculateTuitionFee()))