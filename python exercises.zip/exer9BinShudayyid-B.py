class Person:
    def __init__(self, name, age, ID):
        self.name = name
        self.age = age
        self.ID = ID

    def __str__(self):
        return "name: " + str(self.name) + " age: " + str(self.age) + " ID: " + str(self.ID)


class Student(Person):
    def __init__(self, name, age, ID, major, creditHours):
        super().__init__(name, age, ID)
        self.major = major
        self.creditHours = creditHours

    def __str__(self):
        return "name: " + str(self.name) + " age: " + str(self.age) + " ID " + str(
            self.ID) + " major: " + str(self.major) + " creditHours: " + str(self.creditHours)

    def calculateTuitionFee(self):
        return 500 * self.creditHours


class AthleteStudent(Student):
    def __init__(self, name, age, ID, major, creditHours, sport, hours, weeks):
        super().__init__(name, age, ID, major, creditHours)
        self.sport = sport
        self.hours = 0
        self.weeks = 0


def logTrainingTime(self, hours):
    self.hours += hours
    self.weeks += 1


def reset(self):
    self.hours = 0
    self.weeks = 0


def weeklyAverage(self):
    return self.hours/self.weeks

def __str__(self):
     return super().__str__() + " sport: " + str(self.sport) + " hours: " + str(
     self.hours) + " weeks: " + str(self.weeks)

