import math
#program 1
start_val= eval(input("enter the starting even number"))
end_val = eval(input("enter the ending even number"))
sum=0
while start_val<=end_val:
    sum += start_val
    start_val+=2
print("sum is: ", sum)
#program 2
x=1
sum2=1
z=2
count =0
y=1
while y>=(1/100):

    y= 1/z
    sum2 +=y
    z += 2
    count+=1
average= sum/count
print("sum is:",sum2, " average is: ", average)
#program 3
n =1
while n<=10:
    a = 1000 * math.pow(1+0.05, n)
    print(" profit for year ", n, "is: ", a)
    n+=1