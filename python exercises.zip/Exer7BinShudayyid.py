import math


class Investment:
    def __init__(self, principal, rate, years):
        self.principal = principal
        self.rate = rate
        self.years = years

    def value_after(self):
        return self.principal * math.pow(1 + self.rate, self.years)

    def __str__(self):
        return '{},{},{},{}'.format(self.principal, self.rate, self.years, self.value_after())


emp1 = Investment(1000, 0.0512, 12)
print(emp1.__str__())


import math

class Points:
    def __init__(self, p1x1, p1y1, p2x2, p2y2):
        self.p1x1=p1x1
        self.p1y1=p1y1
        self.p2x2=p2x2
        self.p2y2=p2y2

    def get_p1x1(self):
        return self.p1x1

    def set_p1x1(self, p1x1):
        self.p1x1=p1x1

    def get_p1y1(self):
        return self.p1y1

    def set_p1y1(self, p1y1):
        self.p1y1=p1y1

    def get_p2x2(self):
        return self.p2x2

    def set_p2x2(self, p2x2):
        self.p2x2=p2x2

    def get_p2y2(self):
        return self.p2y2

    def set_p2y2(self, p2y2):
        self.p2y2=p2y2

    def computeMidpoint(self):
        return "("+ str((self.p1x1+self.p2x2)/2) + " , "+ str((self.p1y1+self.p2y2)/2) + ")"

    def computeDistance(self):
        return math.sqrt(math.pow(self.p2x2-self.p1x1,2)+(math.pow(self.p2y2-self.p1y1,2 )))

    def determineSlope(self):
        return (self.p2y2-self.p1y1)/(self.p2x2-self.p1x1)

    def identifyP1Location(self):
        if self.p1x1>0 and self.p1y1>0:
            return "quadrant 1"
        elif self.p1x1<0 and self.p1y1>0:
            return "quadrant 2"
        elif self.p1x1<0 and self.p1y1<0:
            return "quadrant 3"
        elif self.p1x1>0 and self.p1y1<0:
            return "quadrant 4"
        elif self.p1x1==0 and self.p1y1==0:
            return "origin point"
        elif self.p1x1>0 and self.p1y1==0:
            return "positive x-axis"
        elif self.p1x1< 0 and self.p1y1==0:
            return "negative x-axis"
        elif self.p1x1==0 and self.p1y1>0:
            return "postive y-axis"
        elif self.p1x1==0 and self.p1y1<0:
            return "negative y-axis"

    def identifyP2Location(self):
        if self.p2x2 > 0 and self.p2y2 > 0:
            return "quadrant 1"
        elif self.p2x2 < 0 and self.p2y2 > 0:
            return "quadrant 2"
        elif self.p2x2 < 0 and self.p2y2 < 0:
            return "quadrant 3"
        elif self.p2x2 > 0 and self.p2y2 < 0:
            return "quadrant 4"
        elif self.p2x2 == 0 and self.p2y2 == 0:
            return "origin point"
        elif self.p2x2 > 0 and self.p2y2 == 0:
            return "positive x-axis"
        elif self.p2x2 < 0 and self.p2y2 == 0:
            return "negative x-axis"
        elif self.p2x2 == 0 and self.p2y2 > 0:
            return "postive y-axis"
        elif self.p2x2 == 0 and self.p2y2 < 0:
            return "negative y-axis"

    def __str__(self):
        return "p1x1= " + str(self.p1x1) + " p1y1= "+ str(self.p1y1) + " p2x2= "+ str(self.p2x2) + " p2y2= "+str(self.p2y2) + "\n distance "+ str(self.computeDistance()) + "\n mid point "+ self.computeMidpoint() + "\n slope "+ str(self.determineSlope())+ " p2 "+str(self.p2x2)+", " +str(self.p2y2) + " p1 location "+ self.identifyP1Location() + " p2 location "+ self.identifyP2Location()

meow= Points(3, -2, -1, -3)

print(meow.__str__())