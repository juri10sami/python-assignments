import math
import random
string = input("write something")
def change_case(string):
  return  string.swapcase()

print(change_case(string))

n= eval(input("enter n"))
def digital_root(n):
    root = 0
    while n > 0:
        root += n % 10
        n = n // 10
    if root > 9:
        root = digital_root(root)
    return root
l= eval(input("enter l"))
def random1(l):
    if n == 1:
        return random.randint(1, 9)
    elif n == 2:
        return random.randint(10, 99)
    elif n == 3:
        return random.randint(100, 999)
    elif n == 4:
        return random.randint(1000, 9999)
    elif n == 5:
        return random.randint(10000, 99999)
    elif n == 6:
        return random.randint(100000, 999999)
    elif n == 7:
        return random.randint(1000000, 9999999)
    else:
        raise ValueError("The number of digits should be between 1 and 7")

L = list(map(int, input("Enter the list of numbers: ").split()))
n = int(input("Enter the number: "))
def closest(L, n):
    L.sort()
    closest_num = L[0]
    for num in L:
        if num > n:
            break
        closest_num = num
    return closest_num

print(closest(L, n))